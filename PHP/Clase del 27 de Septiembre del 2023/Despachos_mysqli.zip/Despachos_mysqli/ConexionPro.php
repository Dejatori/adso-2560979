<?php
$host = 'localhost:3306';
$usuario = 'root';
$clave = '';
$baseDatos = 'Despachos';
?>