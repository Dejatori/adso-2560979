<?php
// Conexion a la Base Datos
$mysqli=new mysqli('localhost:3306', 'root', '', 'Despachos');

// Averigua si hya problemas de Conexión
if ($mysqli->connect_errno) {
    printf("Conexión fallida: %s\n", $mysqli->connect_error);
    exit();
}  

// Recupera el listado de Unidades de Medida en $Result
$Result=$mysqli->query("SELECT * FROM UNIDADES_MEDIDA");

// Recupera el listado de Productos y lo guarda en $ListPro
$Sql="Select * From Productos";
$ListPro=$mysqli->query($Sql);	  

while($Row=$ListPro->fetch_assoc()) {
     echo $Row['Id_Producto'] . " | " . $Row['Descripcion'] . " | " . $Row['Precio_Unitario'];
?>
	
<select name="Id_Medida" id="Id_Medida">
	<?php foreach ($Result as $Uni) { 
	if (Trim($Uni['Id_Unidad'])==trim($Row['Id_Medida']))
		echo "<option value=".$Uni['Id_Unidad']." Selected>".$Uni['Descripcion']."</option>";
	else
		echo "<option value=".$Uni['Id_Unidad'].">".$Uni['Descripcion']."</option>";
	} ?>
      </select>
	  <a href="Edita.php?Id_Producto=<?php Echo $Row['Id_Producto']?>">Editar</a>
	  <a href="Borra.php?Id_Producto=<?php Echo $Row['Id_Producto']?>">Borrar</a>	  
	  <br>
	  
	  <?php
}

?>


