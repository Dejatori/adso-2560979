<?php
// Conexion a la Base Datos
$mysqli=new mysqli('localhost:3306', 'root', '', 'Despachos');

// Averigua si hya problemas de Conexión
if ($mysqli->connect_errno) {
    printf("Conexión fallida: %s\n", $mysqli->connect_error);
    exit();
}  

// Recupera el listado de Productos y lo guarda en $ListPro
$Sql="Select Id_Producto, P.Descripcion DescPro, P.Precio_Unitario, UM.Descripcion DescMed From Productos P, 
	UNIDADES_MEDIDA UM	Where UM.Id_Unidad=P.Id_Medida";
		
$ListPro=$mysqli->query($Sql);	  
?>
<a href="Edita.php?Id_Producto=<?php Echo $Row['Id_Producto']?>">Nuevo Producto</a><br>
<?php
echo 'Id_Producto' . " | " . 'Producto' . " | " . 'Precio_Unitario' . " | " . 'Medida<br><br>';
while($Row=$ListPro->fetch_assoc()) {
     echo $Row['Id_Producto'] . " | " . $Row['DescPro'] . " | " . $Row['Precio_Unitario'] . " | " . $Row['DescMed'];
?>
	  <a href="Edita.php?Id_Producto=<?php Echo $Row['Id_Producto']?>">Editar</a>
	  <a href="Borra.php?Id_Producto=<?php Echo $Row['Id_Producto']?>">Borrar</a>	  
	  <br>
	  
	  <?php
}

?>


